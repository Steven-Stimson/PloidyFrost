#ifndef BIFROST_DATA_MANAGER_HPP
#define BIFROST_DATA_MANAGER_HPP

#include "ColorSet.hpp"
#include "CompactedDBG.hpp"

#include "DataStorage.hpp"
#include "DataAccessor.hpp"

#include "DataStorage.tcc"
#include "DataAccessor.tcc"

#endif
